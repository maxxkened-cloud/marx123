# Overview

This is a professional landing page application for Melisa García, designed as a single-page contact platform with a focus on immediate accessibility and trust-building. The application features a clean, modern interface with real-time location detection and a prominent call-to-action for Telegram contact. Built with React and TypeScript, it follows a reference-based design approach inspired by professional service platforms like LinkedIn.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **UI Library**: Radix UI components with shadcn/ui component system for accessibility and consistency
- **Styling**: Tailwind CSS with custom design tokens and CSS variables for theming
- **Routing**: Wouter for lightweight client-side routing (single-page application)
- **State Management**: React Query (TanStack Query) for server state management

## Design System
- **Component Library**: shadcn/ui with "new-york" style variant
- **Theme System**: Dark/light mode support with CSS custom properties
- **Typography**: Inter font family for professional appearance
- **Color Palette**: Neutral-based with Telegram blue (#0088ff) for call-to-action elements
- **Responsive Design**: Mobile-first approach with Tailwind's responsive utilities

## Backend Architecture
- **Server**: Express.js with TypeScript for API endpoints
- **Development Stack**: Node.js with ESM modules
- **Static Serving**: Vite development server in dev mode, Express static serving in production
- **Build System**: esbuild for server bundling, Vite for client bundling

## Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: Configured for PostgreSQL via Neon Database
- **Schema**: Basic user authentication schema (username/password)
- **Migrations**: Drizzle Kit for database schema management

## Key Features
- **Real-time Location**: IP-based geolocation with fallback to "Brasil"
- **Online Status**: Dynamic status indicator with visual feedback
- **Profile Card**: Centered hero section with verified badge overlay
- **Theme Toggle**: User preference persistence with system theme detection
- **Responsive Layout**: Optimized for both desktop and mobile devices

## Development Tools
- **Hot Reload**: Vite HMR for instant development feedback
- **Error Handling**: Runtime error overlay plugin for development
- **Type Safety**: Full TypeScript coverage across client and server
- **Code Organization**: Modular component structure with shared utilities

# External Dependencies

## Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management and data fetching

## UI Components
- **@radix-ui**: Accessible headless UI components foundation
- **class-variance-authority**: Type-safe component variants
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library for consistent iconography

## Development Dependencies
- **vite**: Build tool and development server
- **tsx**: TypeScript execution environment
- **esbuild**: Fast JavaScript bundler for server code

## Third-Party Services
- **IP Geolocation API**: `https://ipapi.co/json/` for real-time location detection
- **Google Fonts**: Inter font family for typography
- **Telegram**: Integration via direct bot URL for contact functionality

## Build and Deployment
- **Production Build**: Vite builds client assets, esbuild bundles server
- **Static Assets**: Served from attached_assets directory for profile images
- **Environment Variables**: DATABASE_URL required for database connectivity