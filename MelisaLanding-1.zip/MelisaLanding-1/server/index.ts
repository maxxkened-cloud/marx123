import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Disable ETags to prevent 304 responses during development
app.set('etag', false);

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Add API routes before Vite middleware to avoid conflicts
  app.get("/api/location", async (req, res) => {
    try {
      // Get the real client IP from headers (Replit forwards this)
      let clientIp = req.headers['x-forwarded-for'] || 
                    req.headers['x-real-ip'] || 
                    req.connection.remoteAddress ||
                    req.ip;
      
      // Extract the first IP if there are multiple (common with proxies)
      if (typeof clientIp === 'string' && clientIp.includes(',')) {
        clientIp = clientIp.split(',')[0].trim();
      }
      
      console.log('Detecting location for IP:', clientIp);
      
      // If we detect localhost or private IP, try to get real IP from external service
      if (clientIp === '127.0.0.1' || clientIp === '::1' || typeof clientIp !== 'string' || clientIp.startsWith('10.') || clientIp.startsWith('192.168.') || clientIp.startsWith('172.')) {
        try {
          // Get real public IP first
          const ipResponse = await fetch('https://api.ipify.org?format=json');
          if (ipResponse.ok) {
            const ipData = await ipResponse.json();
            if (ipData.ip) {
              clientIp = ipData.ip;
              console.log('Real public IP detected:', clientIp);
            }
          }
        } catch (error) {
          console.log('Failed to get real IP, using geolocation fallback');
        }
      }
      
      // Try to get location using ipapi.co JSON endpoint (more reliable)
      if (typeof clientIp === 'string') {
        try {
          const response = await fetch(`https://ipapi.co/${clientIp}/json/`, {
            headers: {
              'User-Agent': 'Mozilla/5.0'
            }
          });
          
          if (response.ok) {
            const data = await response.json();
            console.log('Location API response:', data);
            
            // Check if we got valid data
            if (data && data.city && !data.error) {
              const city = data.city.trim();
              const country = data.country_code || 'BR';
              
              console.log('Detected city:', city, 'Country:', country);
              
              res.set("Cache-Control", "no-store, no-cache, must-revalidate");
              res.set("Pragma", "no-cache");
              res.set("Expires", "0");
              
              return res.json({
                city,
                country
              });
            } else if (data && data.error) {
              console.log('Location API error:', data.reason || data.error);
            }
          } else {
            console.log('Location API failed with status:', response.status);
          }
        } catch (error) {
          console.log('Location detection failed:', error instanceof Error ? error.message : 'Unknown error');
        }
      }
      
      // Set no-cache headers to prevent 304 responses
      res.set("Cache-Control", "no-store, no-cache, must-revalidate");
      res.set("Pragma", "no-cache");
      res.set("Expires", "0");
      
      // Fallback: return Brasil
      res.json({
        city: 'Brasil',
        country: 'BR'
      });
      
    } catch (error) {
      console.error('Location API error:', error);
      res.status(500).json({ 
        error: 'Failed to get location',
        city: 'Brasil',
        country: 'BR' 
      });
    }
  });

  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
