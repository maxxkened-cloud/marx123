# Deploy no Netlify - Instruções

Este projeto foi adaptado para funcionar perfeitamente no Netlify com arquitetura serverless.

## 📋 O que foi feito

✅ Backend Express convertido para **Netlify Functions** (serverless)  
✅ API de geolocalização (`/api/location`) funcionando como serverless function  
✅ Frontend React otimizado para build estático  
✅ Todas as imagens e assets incluídos no build  
✅ Configuração automática via `netlify.toml`  

## 🚀 Como fazer deploy no Netlify

### Opção 1: Deploy via Interface Web (Mais Fácil)

1. **Acesse** [netlify.com](https://netlify.com) e faça login
2. Clique em **"Add new site"** → **"Import an existing project"**
3. Conecte seu repositório Git (GitHub, GitLab ou Bitbucket)
4. **Configurações são automáticas!** O Netlify detectará o `netlify.toml`
   - Build command: `vite build`
   - Publish directory: `dist/public`
   - Functions directory: `netlify/functions`
5. Clique em **"Deploy site"**

### Opção 2: Deploy via Netlify CLI

```bash
# Instalar Netlify CLI (uma vez)
npm install -g netlify-cli

# Fazer login
netlify login

# Fazer build
vite build

# Deploy
netlify deploy --prod --dir=dist/public --functions=netlify/functions
```

## 🔧 Arquitetura

### Frontend
- **React + Vite** → build estático em `dist/public`
- Todas as rotas SPA funcionam (redirect para `index.html`)

### Backend (Serverless)
- **Netlify Function** em `netlify/functions/location.ts`
- Endpoint: `/api/location` (detecção automática de geolocalização)
- Usa `ipapi.co` para detectar cidade baseada no IP

### Geolocalização
A API de geolocalização funciona automaticamente:
- Detecta IP do visitante via headers do Netlify
- Consulta localização via ipapi.co
- Retorna cidade e país em JSON
- Fallback para "Brasil" se não detectar

## 📦 Estrutura de Arquivos

```
/
├── client/               # Frontend React
├── netlify/
│   └── functions/
│       └── location.ts   # API serverless de geolocalização
├── attached_assets/      # Imagens (incluídas no build)
├── netlify.toml         # Configuração do Netlify
└── dist/public/         # Build final (gerado)
```

## ✅ Checklist Pós-Deploy

Após o deploy, verifique:
- [ ] Site carrega corretamente
- [ ] Geolocalização mostra sua cidade
- [ ] Todas as imagens aparecem
- [ ] Botão do Telegram funciona
- [ ] Tema claro/escuro funciona
- [ ] Links dos termos e privacidade funcionam

## 🌍 Funcionamento da Geolocalização

Quando alguém acessa o site:
1. O Netlify detecta o IP automaticamente
2. A função serverless consulta a localização
3. Mostra a cidade no perfil (ex: "São Paulo", "Rio de Janeiro")
4. Funciona para qualquer lugar do mundo!

## 💡 Dicas

- **Domínio personalizado**: Configure em Site settings → Domain management
- **Variáveis de ambiente**: Configure em Site settings → Environment variables
- **Logs**: Veja em Functions → Function logs
- **Analytics**: Ative em Integrations → Analytics

## 🔒 Observações

- A API ipapi.co tem limite de 1.000 requisições/dia (grátis)
- Se exceder, o sistema usa fallback "Brasil"
- Para mais requisições, considere upgrade do ipapi.co ou API alternativa

---

**Pronto!** Seu site está configurado para funcionar perfeitamente no Netlify! 🎉
