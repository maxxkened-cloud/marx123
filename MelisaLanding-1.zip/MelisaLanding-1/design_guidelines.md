# Design Guidelines for Melisa García Landing Page

## Design Approach
**Reference-Based Approach**: Drawing inspiration from professional service platforms like LinkedIn and modern freelancer portfolios, with emphasis on trust-building and immediate contact accessibility.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Dark Mode: 240 15% 12% (background), 240 10% 20% (cards)
- Light Mode: 220 20% 98% (background), 0 0% 100% (cards)
- Accent: 220 90% 56% (Telegram blue for CTA button)

**Supporting Colors:**
- Success green: 142 76% 36% (online status)
- Text primary: 240 10% 90% (dark) / 240 10% 10% (light)
- Text secondary: 240 5% 65% (dark) / 240 5% 45% (light)

### Typography
- **Primary Font**: Inter (Google Fonts) - clean, professional
- **Hierarchy**: 
  - Hero name: text-4xl font-bold
  - Location/status: text-lg font-medium
  - Body text: text-base
  - Labels: text-sm font-medium

### Layout System
**Tailwind Spacing Units**: Consistent use of 2, 4, 6, 8, 12, 16, 24
- Container padding: px-4 md:px-8
- Section spacing: py-8 md:py-12
- Card padding: p-6 md:p-8
- Element gaps: gap-4, gap-6, gap-8

## Component Library

### Core Components
1. **Profile Card**: Centered hero section with circular profile photo (128px), verified badge overlay, name, and real-time location
2. **Status Indicator**: Dynamic online status with green dot and city display
3. **Contact CTA**: Prominent Telegram button with icon and hover effects
4. **Location Display**: Real-time city detection with subtle animation

### Navigation
Minimal approach - no traditional navigation needed for single-page landing

### Visual Treatments
- **Card Design**: Subtle shadows (shadow-lg), rounded corners (rounded-xl)
- **Profile Photo**: Circular with subtle border, verified badge positioned top-right
- **Animations**: Gentle fade-in on load, pulse effect on online status dot
- **Gradients**: Subtle gradient overlay on any background images

## Responsive Design
- Mobile-first approach
- Profile card: Full width on mobile, centered max-width on desktop
- Button: Full width on mobile, auto width on desktop
- Optimal viewing on screens 320px to 1200px+

## Key Design Principles
1. **Trust & Credibility**: Professional photo, verified badge, real location
2. **Immediate Action**: Prominent Telegram contact button
3. **Minimal Friction**: Single-purpose landing page focused on contact
4. **Dynamic Elements**: Live location and online status for authenticity
5. **Mobile Optimization**: Primary focus on mobile experience

## Images
**Profile Photo**: Professional headshot, circular crop, high resolution for retina displays. No additional hero images needed - the profile photo serves as the primary visual element.

**Layout**: Single-viewport design with centered profile card containing photo, name, location, status, and contact button - no scrolling required.