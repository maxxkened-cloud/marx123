import { Link } from 'wouter';

export default function Footer() {
  return (
    <footer className="w-full py-6 px-4 text-center border-t mt-auto">
      <div className="text-sm text-muted-foreground space-y-2">
        <p>©2025 closedagarcia</p>
        <div className="flex justify-center items-center gap-4 flex-wrap">
          <Link href="/termos" className="hover:text-foreground underline transition-colors" data-testid="link-terms">
            Termos e condições
          </Link>
          <span className="text-muted-foreground">•</span>
          <Link href="/privacidade" className="hover:text-foreground underline transition-colors" data-testid="link-privacy">
            Política de privacidade
          </Link>
        </div>
      </div>
    </footer>
  );
}