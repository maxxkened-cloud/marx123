import ProfileCard from '../ProfileCard';

export default function ProfileCardExample() {
  return (
    <ProfileCard 
      name="Melisa garcia" 
      telegramUrl="https://t.me/melissagarcy_bot"
      responseTime="menos de 2 minutos"
    />
  );
}