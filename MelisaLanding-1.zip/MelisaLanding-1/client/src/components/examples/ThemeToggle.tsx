import ThemeToggle from '../ThemeToggle';

export default function ThemeToggleExample() {
  return (
    <div className="relative h-64 bg-background">
      <ThemeToggle />
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">Theme toggle in top right corner</p>
      </div>
    </div>
  );
}