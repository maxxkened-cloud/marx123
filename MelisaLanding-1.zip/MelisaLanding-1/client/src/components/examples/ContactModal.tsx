import { Button } from '@/components/ui/button';
import ContactModal from '../ContactModal';

export default function ContactModalExample() {
  return (
    <div className="flex items-center justify-center p-8">
      <ContactModal>
        <Button variant="outline">
          Open Contact Modal
        </Button>
      </ContactModal>
    </div>
  );
}