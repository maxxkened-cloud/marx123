import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Mail } from 'lucide-react';
import { SiTelegram } from 'react-icons/si';
import { Link } from 'wouter';
import ContactModal from './ContactModal';
import profileImage from '@assets/dxdwbc_1758572897045.png';
import backgroundImage from '@assets/melds_1758571150341.png';
import locationIcon from '@assets/vetor-de-ícone-localização-casa-conceito-símbolo-mapa-endereço-residencial-do-278430232-Photoroom_1758571871505.png';
import verifiedIcon from '@assets/sss_1758574601634.png';

interface LocationData {
  city: string;
  country: string;
}

interface ProfileCardProps {
  name: string;
  telegramUrl: string;
  responseTime?: string;
}

export default function ProfileCard({ name, telegramUrl, responseTime = "menos de 2 minutos" }: ProfileCardProps) {
  const [location, setLocation] = useState<string>("Localizando...");
  const [isOnline] = useState(true);
  const [isLoadingLocation, setIsLoadingLocation] = useState(true);

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    
    // Set a timeout for location detection (8 seconds)
    timeoutId = setTimeout(() => {
      if (isLoadingLocation) {
        setLocation("Brasil");
        setIsLoadingLocation(false);
      }
    }, 8000);

    // Use IP-based geolocation without asking permission (better UX)
    // Try multiple APIs for better accuracy
    detectLocationAutomatically();

    async function detectLocationAutomatically() {
      try {
        // Use our improved backend API that gets the real client IP
        const response = await fetch("/api/location", { 
          cache: 'no-store',
          headers: {
            'Cache-Control': 'no-cache'
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          clearTimeout(timeoutId);
          
          // Show city if we have one, otherwise show country or Brasil
          if (data.city) {
            setLocation(data.city);
          } else if (data.country === 'BR') {
            setLocation("Brasil");
          } else {
            setLocation("Brasil");
          }
          setIsLoadingLocation(false);
          return;
        }
      } catch (error) {
        console.log('Location detection failed:', error);
      }

      // API failed, use default
      clearTimeout(timeoutId);
      setLocation("Brasil");
      setIsLoadingLocation(false);
    }

    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, []);

  const handleTelegramClick = () => {
    // Analytics tracking
    if (typeof window !== 'undefined' && 'gtag' in window) {
      (window as any).gtag('event', 'telegram_contact_click', {
        event_category: 'engagement',
        event_label: 'telegram_button',
        value: 1
      });
    }
    
    console.log('Telegram contact clicked - analytics tracked');
    window.open(telegramUrl, '_blank');
  };

  return (
    <div className="p-0 sm:p-4">
      <Card 
        className="w-full h-screen sm:max-w-md sm:h-auto text-center hover-elevate animate-in fade-in-0 slide-in-from-bottom-4 duration-700 sm:mx-auto relative overflow-hidden sm:rounded-lg rounded-none"
        style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          aspectRatio: 'auto',
          minHeight: '100vh'
        }}
      >
        {/* Gradient overlay for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent sm:rounded-lg" />
        
        {/* Content wrapper - positioned at bottom like an overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 space-y-3 sm:space-y-4 z-10">
        {/* Profile Photo with Verified Badge */}
        <div className="relative mx-auto w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32">
          <Avatar className="w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 border-2 sm:border-4 border-white shadow-lg">
            <AvatarImage 
              src={profileImage} 
              alt={name}
              className="object-cover"
              data-testid="img-profile"
            />
            <AvatarFallback className="text-lg sm:text-xl md:text-2xl font-bold">
              {name.split(' ').map(n => n[0]).join('').toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          {/* Verified Badge */}
          <div className="absolute bottom-0 right-0 sm:bottom-0 sm:right-1 w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10">
            <img src={verifiedIcon} alt="Verificado" className="w-full h-full object-contain ml-[6px] mr-[6px] mt-[-5px] mb-[-5px] pt-[1px] pb-[1px] pl-[0px] pr-[0px]" />
          </div>
        </div>

        {/* Name */}
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white" data-testid="text-name">
            {name}
          </h1>
        </div>

        {/* Online Status */}
        <div className="flex items-center justify-center gap-2" data-testid="status-online">
          <div className={`w-3 h-3 rounded-full ${isOnline ? 'bg-green-500' : 'bg-gray-400'} ${isOnline ? 'animate-pulse' : ''}`} />
          <span className="text-sm sm:text-base text-white/90">
            {isOnline ? 'Online Agora' : 'Offline'} • <img src={locationIcon} alt="location" className="inline w-6 h-6 mx-1" /> {isLoadingLocation ? (
              <span className="inline-flex items-center gap-1">
                Localizando...
                <div className="animate-spin w-3 h-3 border border-current border-t-transparent rounded-full" />
              </span>
            ) : location}
          </span>
        </div>

        {/* Telegram Contact Button */}
        <Button
          onClick={handleTelegramClick}
          className="w-full py-3 sm:py-4 md:py-6 text-base sm:text-lg font-semibold bg-white hover:bg-gray-50 text-black border-2 border-gray-200 shadow-lg telegram-pulse"
          data-testid="button-telegram"
        >
          <div className="flex items-center justify-center w-full text-right ml-[0px] mr-[0px] mt-[-5px] mb-[-5px] pl-[5px] pr-[5px] pt-[2px] pb-[2px]">
            <SiTelegram className="mr-2 sm:mr-3 h-8 w-8 sm:h-10 sm:w-10 text-[#0088cc]" />
            <div className="text-center">
              <div className="font-bold text-sm sm:text-base">MEU TELEGRAM PESSOAL 🎁</div>
              <div className="text-xs sm:text-sm font-normal text-gray-600 mt-1">
                Respondo em {responseTime}
              </div>
            </div>
          </div>
        </Button>

        {/* Status Badge */}
        <Badge variant="secondary" className="mx-auto animate-pulse text-xs sm:text-sm bg-white/20 text-white border-white/30">
          Estou disponível
        </Badge>

        {/* Footer Info */}
        <div className="text-center space-y-1 mt-4 pt-4 border-t border-white/20">
          <p className="text-[10px] text-white/70">©2025 closedagarcia</p>
          <div className="flex justify-center items-center gap-2 flex-wrap text-[10px]">
            <Link href="/termos" className="text-white/70 hover:text-white underline transition-colors" data-testid="link-terms">
              Termos e condições
            </Link>
            <span className="text-white/50">•</span>
            <Link href="/privacidade" className="text-white/70 hover:text-white underline transition-colors" data-testid="link-privacy">
              Política de privacidade
            </Link>
          </div>
        </div>
        </div>
      </Card>
    </div>
  );
}