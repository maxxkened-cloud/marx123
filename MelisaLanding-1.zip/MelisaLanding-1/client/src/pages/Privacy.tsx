import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import Footer from '@/components/Footer';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="container max-w-4xl mx-auto px-4 py-8 flex-1">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4" data-testid="button-back">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Política de Privacidade</CardTitle>
            <p className="text-muted-foreground">
              Última atualização: {new Date().toLocaleDateString('pt-BR')}
            </p>
          </CardHeader>
          <CardContent className="prose prose-sm max-w-none space-y-6">
            <section>
              <h3 className="text-lg font-semibold mb-3">1. Informações que Coletamos</h3>
              <p>Coletamos as seguintes informações quando você utiliza nossos serviços:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Dados de contato:</strong> Nome, email, mensagens enviadas</li>
                <li><strong>Dados de localização:</strong> Cidade aproximada baseada em IP (para personalização)</li>
                <li><strong>Dados de navegação:</strong> Páginas visitadas, cliques em botões</li>
                <li><strong>Dados do Telegram:</strong> ID do usuário, mensagens (quando aplicável)</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">2. Como Utilizamos suas Informações</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>Responder às suas solicitações e fornecer suporte</li>
                <li>Personalizar a experiência do usuário (exibição de localização)</li>
                <li>Melhorar nossos serviços através de análise de uso</li>
                <li>Comunicar sobre atualizações importantes dos serviços</li>
                <li>Cumprir obrigações legais quando necessário</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">3. Compartilhamento de Dados</h3>
              <p>
                <strong>Não vendemos ou alugamos seus dados pessoais.</strong> Podemos compartilhar 
                informações apenas nas seguintes situações:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Com seu consentimento explícito</li>
                <li>Para cumprir obrigações legais ou ordens judiciais</li>
                <li>Com prestadores de serviços que nos auxiliam (sempre com contratos de confidencialidade)</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">4. Cookies e Tecnologias Similares</h3>
              <p>
                Utilizamos cookies e tecnologias similares para melhorar sua experiência, 
                incluindo preferências de tema (modo claro/escuro) e análise básica de uso.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">5. Seus Direitos (LGPD)</h3>
              <p>Conforme a Lei Geral de Proteção de Dados, você tem direito a:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Confirmar a existência de tratamento de dados</li>
                <li>Acessar seus dados pessoais</li>
                <li>Corrigir dados incompletos ou inexatos</li>
                <li>Solicitar a eliminação de dados desnecessários</li>
                <li>Revogar seu consentimento a qualquer momento</li>
                <li>Solicitar a portabilidade de dados</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">6. Segurança dos Dados</h3>
              <p>
                Implementamos medidas técnicas e organizacionais apropriadas para proteger 
                seus dados contra acesso não autorizado, alteração, divulgação ou destruição.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">7. Retenção de Dados</h3>
              <p>
                Mantemos seus dados apenas pelo tempo necessário para os fins descritos 
                nesta política, ou conforme exigido por lei.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">8. Contato e Exercício de Direitos</h3>
              <p>
                Para exercer seus direitos ou esclarecer dúvidas sobre esta política, 
                entre em contato através do Telegram ou formulário disponível em nossa página principal.
              </p>
              <p className="text-sm text-muted-foreground mt-4">
                <strong>Encarregado de Dados:</strong> Melisa García<br/>
                <strong>Canais de contato:</strong> Disponíveis na página principal
              </p>
            </section>
          </CardContent>
        </Card>
      </div>
      <Footer />
    </div>
  );
}