import ProfileCard from '@/components/ProfileCard';
import ThemeToggle from '@/components/ThemeToggle';

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col px-2 sm:px-4">
      <ThemeToggle />
      <ProfileCard 
        name="Melisa garcia" 
        telegramUrl="https://t.me/melissagarcy_bot"
        responseTime="menos de 2 minutos"
      />
    </div>
  );
}