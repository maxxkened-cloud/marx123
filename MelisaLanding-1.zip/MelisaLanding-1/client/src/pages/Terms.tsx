import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import Footer from '@/components/Footer';

export default function Terms() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="container max-w-4xl mx-auto px-4 py-8 flex-1">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="mb-4" data-testid="button-back">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Termos e Condições</CardTitle>
            <p className="text-muted-foreground">
              Última atualização: {new Date().toLocaleDateString('pt-BR')}
            </p>
          </CardHeader>
          <CardContent className="prose prose-sm max-w-none space-y-6">
            <section>
              <h3 className="text-lg font-semibold mb-3">1. Aceitação dos Termos</h3>
              <p>
                Ao utilizar os serviços oferecidos por Melisa García ("closedagarcia"), você concorda 
                em cumprir estes termos e condições. Se você não concordar com qualquer parte destes 
                termos, não deve utilizar nossos serviços.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">2. Descrição dos Serviços</h3>
              <p>
                Oferecemos serviços de consultoria e atendimento personalizado através de canais de 
                comunicação digital, incluindo Telegram e formulário de contato. Os serviços específicos 
                serão detalhados durante o primeiro contato.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">3. Responsabilidades do Cliente</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>Fornecer informações precisas e atualizadas</li>
                <li>Manter a confidencialidade de informações sensíveis</li>
                <li>Utilizar os serviços de forma ética e legal</li>
                <li>Pagar pelos serviços conforme acordado</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">4. Limitação de Responsabilidade</h3>
              <p>
                Os serviços são fornecidos "como estão". Não garantimos resultados específicos 
                e nossa responsabilidade é limitada ao valor pago pelos serviços contratados.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">5. Privacidade e Dados</h3>
              <p>
                O tratamento de dados pessoais está descrito em nossa 
                <Link href="/privacidade">
                  <a className="text-primary underline mx-1">Política de Privacidade</a>
                </Link>
                e segue as diretrizes da LGPD.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">6. Modificações</h3>
              <p>
                Reservamos o direito de modificar estes termos a qualquer momento. 
                As alterações entrarão em vigor imediatamente após a publicação nesta página.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-3">7. Contato</h3>
              <p>
                Para dúvidas sobre estes termos, entre em contato através do Telegram 
                ou formulário disponível em nossa página principal.
              </p>
            </section>
          </CardContent>
        </Card>
      </div>
      <Footer />
    </div>
  );
}