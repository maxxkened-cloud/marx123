import type { Handler } from "@netlify/functions";

export const handler: Handler = async (event) => {
  try {
    // Get the real client IP from Netlify headers (most reliable)
    let clientIp = event.headers['x-nf-client-connection-ip'] || 
                   event.headers['x-forwarded-for'] || 
                   event.headers['x-real-ip'];
    
    // Extract the first IP if there are multiple (common with proxies)
    if (clientIp && clientIp.includes(',')) {
      clientIp = clientIp.split(',')[0].trim();
    }
    
    console.log('Detecting location for IP:', clientIp);
    
    // If we detect localhost or private IP, try to get real IP from external service
    if (!clientIp || clientIp === '127.0.0.1' || clientIp === '::1' || 
        clientIp.startsWith('10.') || clientIp.startsWith('192.168.') || 
        clientIp.startsWith('172.')) {
      try {
        // Get real public IP first
        const ipResponse = await fetch('https://api.ipify.org?format=json');
        if (ipResponse.ok) {
          const ipData = await ipResponse.json();
          if (ipData.ip) {
            clientIp = ipData.ip;
            console.log('Real public IP detected:', clientIp);
          }
        }
      } catch (error) {
        console.log('Failed to get real IP, using geolocation fallback');
      }
    }
    
    // Try to get location using ipapi.co JSON endpoint (more reliable)
    if (clientIp) {
      try {
        const response = await fetch(`https://ipapi.co/${clientIp}/json/`, {
          headers: {
            'User-Agent': 'Mozilla/5.0'
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          console.log('Location API response:', data);
          
          // Check if we got valid data
          if (data && data.city && !data.error) {
            const city = data.city.trim();
            const country = data.country_code || 'BR';
            
            console.log('Detected city:', city, 'Country:', country);
            
            return {
              statusCode: 200,
              headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-store, no-cache, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
              },
              body: JSON.stringify({
                city,
                country
              })
            };
          } else if (data && data.error) {
            console.log('Location API error:', data.reason || data.error);
          }
        } else {
          console.log('Location API failed with status:', response.status);
        }
      } catch (error) {
        console.log('Location detection failed:', error instanceof Error ? error.message : 'Unknown error');
      }
    }
    
    // Fallback: return Brasil
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      },
      body: JSON.stringify({
        city: 'Brasil',
        country: 'BR'
      })
    };
    
  } catch (error) {
    console.error('Location API error:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      },
      body: JSON.stringify({ 
        error: 'Failed to get location',
        city: 'Brasil',
        country: 'BR' 
      })
    };
  }
};
